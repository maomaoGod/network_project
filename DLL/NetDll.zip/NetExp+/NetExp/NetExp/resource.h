//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� NetExp.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDD_NETEXP_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_NetExpTYPE                  130
#define IDC_INPUT                       1003
#define IDC_ADD                         1004
#define IDC_DES                         1005
#define IDC_DEC                         1005
#define IDC_MUL                         1006
#define IDC_DIV                         1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
