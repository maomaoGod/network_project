// MyServeSocket.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Serve.h"
#include "MyServeSocket.h"
#include  "ClientSocket.h"
#include <vector> 

extern void PrintView(CString);

using namespace std;
vector <ClientSocket> myclient;



// MyServeSocket

MyServeSocket::MyServeSocket()
{
}

MyServeSocket::~MyServeSocket()
{
}


// MyServeSocket ��Ա����


void MyServeSocket::OnAccept(int nErrorCode)
{
	// TODO:  �ڴ�����ר�ô����/����û���
	ClientSocket   *clientsocket = new ClientSocket();
	CAsyncSocket::OnAccept(nErrorCode);
	this->Accept(*clientsocket);
	myclient.push_back(*clientsocket);
}