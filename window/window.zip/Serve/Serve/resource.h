//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Serve.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_ServeTYPE                   130
#define IDI_ICON1                       311
#define IDD_DNSADDR                         312
#define IDD_DIALOG1                     313
#define IDC_domain                      1000
#define IDC_IPADDRESS                   1002
#define IDCOK                           1004
#define ID_32771                        32771
#define ADD_DNSADDR                         32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
