/**
*{{NO_DEPENDENCIES}}\n
* Microsoft Visual C++ ���ɵİ����ļ���\n
* �� HustNet.rc ʹ��
*/
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_HustNetTYPE                 130
#define IDD_DIALOG1                     312
#define IDD_SET                         312
#define IDI_ICON1                       317
#define IDC_COMBO1                      1006
#define IDC_COMBO2                      1007
#define IDC_EDIT1                       1008
#define IDC_local_text                  1008
#define IDC_EDIT2                       1009
#define IDC_server_text                 1009
#define IDC_BUTTON1                     1010
#define IDC_BUTTON2                     1011
#define IDC_LOCAL_Browse                1011
#define IDC_BUTTON3                     1012
#define IDC_Server_Browse               1012
#define IDC_BUTTON4                     1013
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_BUTTON32775                  32775
#define ID_32776                        32776
#define ID_NETSET                       32777

/**
*Next default values for new objects
*/ 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           311
#endif
#endif
