// CmdView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HustNet.h"
#include "CmdView.h"
#include "MainFrm.h"


// CmdView

IMPLEMENT_DYNCREATE(CmdView, CFormView)

CmdView::CmdView()
	: CFormView(CmdView::IDD)
{

}

CmdView::~CmdView()
{
}

void CmdView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CmdView, CFormView)
END_MESSAGE_MAP()


// CmdView ���

#ifdef _DEBUG
void CmdView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CmdView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CmdView ��Ϣ��������


BOOL CmdView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO:  �ڴ�����ר�ô����/����û���
/*	CMainFrame *pframe;
	CWnd  *pwnd;
	pframe = (CMainFrame *)AfxGetApp()->GetMainWnd();
	pwnd=pframe->s_splitter.GetPane(0, 0);
	CRect rect;
	pwnd->GetWindowRect(rect);
	cs.cx = rect.Width();
	cs.cy = rect.Height();*/
	return CFormView::PreCreateWindow(cs);
}
